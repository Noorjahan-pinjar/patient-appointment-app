"""Shared dependencies: who is logged in, and role checks."""
import sqlite3
from typing import Optional

from fastapi import Depends
from fastapi.security import OAuth2PasswordBearer

from . import services
from .db import get_db
from .errors import DomainError

# tokenUrl lets the "Authorize" button in /docs log in with a username and password.
oauth2 = OAuth2PasswordBearer(tokenUrl="/auth/token", auto_error=False)


def get_actor(
    token: Optional[str] = Depends(oauth2),
    db: sqlite3.Connection = Depends(get_db),
) -> dict:
    if not token:
        raise DomainError(401, "Please log in.")
    actor = services.user_from_token(db, token)
    if actor is None:
        raise DomainError(401, "Your login has expired. Please log in again.")
    return actor


def require_roles(*roles: str):
    def check(actor: dict = Depends(get_actor)) -> dict:
        if actor["role"] not in roles:
            raise DomainError(403, "You do not have permission to do this.")
        return actor

    return check


admin_only = require_roles("admin")
