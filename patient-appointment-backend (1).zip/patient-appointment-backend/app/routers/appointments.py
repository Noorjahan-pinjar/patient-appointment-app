import datetime as dt
import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, Query

from .. import services
from ..db import get_db
from ..deps import get_actor
from ..schemas import (
    AppointmentIn,
    AppointmentOut,
    AppointmentPage,
    CancelIn,
    CompleteIn,
    RescheduleIn,
)

router = APIRouter(prefix="/appointments", tags=["Appointments"])


@router.post("", response_model=AppointmentOut, status_code=201, summary="Book an appointment")
def book(body: AppointmentIn, db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(get_actor)):
    return services.book_appointment(
        db, actor, doctor_id=body.doctor_id, on_date=body.date, time_str=body.time.strftime("%H:%M"),
        reason=body.reason, patient_id=body.patient_id,
    )


@router.get("", response_model=AppointmentPage, summary="List appointments (each role sees its own scope)")
def list_appointments(
    status: Optional[str] = Query(None, description="Booked, Completed, Cancelled or NoShow"),
    date_from: Optional[dt.date] = None,
    date_to: Optional[dt.date] = None,
    doctor_id: Optional[int] = None,
    patient_id: Optional[int] = None,
    newest_first: bool = False,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: sqlite3.Connection = Depends(get_db),
    actor: dict = Depends(get_actor),
):
    items, total = services.list_appointments(
        db, actor, status=status, date_from=date_from, date_to=date_to, doctor_id=doctor_id,
        patient_id=patient_id, newest_first=newest_first, limit=limit, offset=offset,
    )
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/{appointment_id}", response_model=AppointmentOut, summary="One appointment")
def get_one(appointment_id: int, db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(get_actor)):
    return services.get_appointment(db, actor, appointment_id)


@router.patch("/{appointment_id}/cancel", response_model=AppointmentOut, summary="Cancel")
def cancel(appointment_id: int, body: CancelIn = CancelIn(), db: sqlite3.Connection = Depends(get_db),
           actor: dict = Depends(get_actor)):
    return services.cancel_appointment(db, actor, appointment_id, body.reason)


@router.patch("/{appointment_id}/reschedule", response_model=AppointmentOut, summary="Move to a new slot")
def reschedule(appointment_id: int, body: RescheduleIn, db: sqlite3.Connection = Depends(get_db),
               actor: dict = Depends(get_actor)):
    return services.reschedule_appointment(db, actor, appointment_id, body.date, body.time.strftime("%H:%M"))


@router.patch("/{appointment_id}/complete", response_model=AppointmentOut,
              summary="Doctor finishes the visit and records notes")
def complete(appointment_id: int, body: CompleteIn = CompleteIn(), db: sqlite3.Connection = Depends(get_db),
             actor: dict = Depends(get_actor)):
    return services.complete_appointment(
        db, actor, appointment_id, notes=body.notes, diagnosis=body.diagnosis, prescription=body.prescription
    )


@router.patch("/{appointment_id}/no-show", response_model=AppointmentOut, summary="Patient did not come")
def no_show(appointment_id: int, db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(get_actor)):
    return services.mark_no_show(db, actor, appointment_id)
