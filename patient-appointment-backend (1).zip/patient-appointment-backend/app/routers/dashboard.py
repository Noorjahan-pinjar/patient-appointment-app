import sqlite3

from fastapi import APIRouter, Depends

from .. import services
from ..db import get_db
from ..deps import get_actor
from ..schemas import SummaryOut

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/summary", response_model=SummaryOut,
            summary="Numbers and lists for the dashboard, matched to the logged-in role")
def summary(db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(get_actor)):
    return services.dashboard_summary(db, actor)
