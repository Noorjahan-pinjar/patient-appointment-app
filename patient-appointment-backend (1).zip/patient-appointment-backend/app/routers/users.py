import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, Query

from .. import services
from ..db import get_db
from ..deps import admin_only
from ..schemas import ActiveIn, UserOut, UserPage

router = APIRouter(prefix="/users", tags=["Users (admin)"])


@router.get("", response_model=UserPage, summary="List all accounts")
def list_users(
    role: Optional[str] = Query(None, pattern="^(admin|doctor|patient)$"),
    q: Optional[str] = Query(None, description="Search name, username or email"),
    is_active: Optional[bool] = None,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: sqlite3.Connection = Depends(get_db),
    _admin: dict = Depends(admin_only),
):
    items, total = services.list_users(db, role=role, q=q, is_active=is_active, limit=limit, offset=offset)
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.patch("/{user_id}/active", response_model=UserOut, summary="Enable or disable an account")
def set_active(
    user_id: int,
    body: ActiveIn,
    db: sqlite3.Connection = Depends(get_db),
    admin: dict = Depends(admin_only),
):
    return services.set_user_active(db, admin, user_id, body.is_active)
