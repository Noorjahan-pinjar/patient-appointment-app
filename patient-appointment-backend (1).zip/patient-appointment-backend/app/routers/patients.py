import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, Query

from .. import services
from ..db import get_db
from ..deps import get_actor, require_roles
from ..errors import DomainError
from ..schemas import AppointmentPage, PatientOut, PatientPage, PatientProfileIn

router = APIRouter(prefix="/patients", tags=["Patients"])


@router.get("", response_model=PatientPage, summary="List patients (admin: all, doctor: own patients)")
def list_patients(
    q: Optional[str] = Query(None, description="Search name, username or phone"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: sqlite3.Connection = Depends(get_db),
    actor: dict = Depends(require_roles("admin", "doctor")),
):
    items, total = services.list_patients(db, actor, q=q, limit=limit, offset=offset)
    return {"items": items, "total": total, "limit": limit, "offset": offset}


# "/me" must be declared before "/{patient_id}" or "me" would be read as an id.
@router.get("/me", response_model=PatientOut, summary="My profile")
def my_profile(db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(require_roles("patient"))):
    return services.get_patient(db, actor, actor["id"])


@router.put("/me", response_model=PatientOut, summary="Update my profile")
def update_my_profile(
    body: PatientProfileIn,
    db: sqlite3.Connection = Depends(get_db),
    actor: dict = Depends(require_roles("patient")),
):
    return services.update_patient_profile(db, actor["id"], body.model_dump(exclude_unset=True))


@router.get("/{patient_id}", response_model=PatientOut, summary="One patient's profile")
def get_patient(patient_id: int, db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(get_actor)):
    return services.get_patient(db, actor, patient_id)


@router.get("/{patient_id}/appointments", response_model=AppointmentPage, summary="A patient's visit history")
def patient_history(
    patient_id: int,
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: sqlite3.Connection = Depends(get_db),
    actor: dict = Depends(get_actor),
):
    services.get_patient(db, actor, patient_id)  # 404 unless this user may see the patient
    items, total = services.list_appointments(
        db, actor, patient_id=patient_id, newest_first=True, limit=limit, offset=offset
    )
    return {"items": items, "total": total, "limit": limit, "offset": offset}
