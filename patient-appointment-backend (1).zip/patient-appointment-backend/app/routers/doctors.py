import datetime as dt
import sqlite3
from typing import Optional

from fastapi import APIRouter, Depends, Query, Response

from .. import services
from ..db import get_db
from ..deps import admin_only, get_actor, require_roles
from ..schemas import (
    DoctorCreateIn,
    DoctorOut,
    DoctorPage,
    DoctorUpdateIn,
    LeaveIn,
    LeaveOut,
    ScheduleItem,
    SlotsOut,
)

router = APIRouter(prefix="/doctors", tags=["Doctors"])


@router.get("", response_model=DoctorPage, summary="Find doctors")
def list_doctors(
    specialization: Optional[str] = Query(None, description="For example Cardiologist"),
    q: Optional[str] = Query(None, description="Part of a name or specialization"),
    include_inactive: bool = Query(False, description="Admin only"),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    db: sqlite3.Connection = Depends(get_db),
    actor: dict = Depends(get_actor),
):
    items, total = services.list_doctors(
        db, specialization=specialization, q=q,
        include_inactive=include_inactive and actor["role"] == "admin", limit=limit, offset=offset,
    )
    return {"items": items, "total": total, "limit": limit, "offset": offset}


@router.get("/specializations", response_model=list[str], summary="All specializations")
def specializations(db: sqlite3.Connection = Depends(get_db), _actor: dict = Depends(get_actor)):
    return services.list_specializations(db)


@router.get("/me", response_model=DoctorOut, summary="My doctor profile")
def my_profile(db: sqlite3.Connection = Depends(get_db), actor: dict = Depends(require_roles("doctor"))):
    return services.get_doctor(db, actor["doctor_id"])


@router.post("", response_model=DoctorOut, status_code=201, summary="Add a doctor with a login")
def create_doctor(body: DoctorCreateIn, db: sqlite3.Connection = Depends(get_db),
                  _admin: dict = Depends(admin_only)):
    data = body.model_dump(exclude={"schedule"})
    data["schedule"] = [item.as_dict() for item in body.schedule]
    return services.create_doctor(db, data)


@router.get("/{doctor_id}", response_model=DoctorOut, summary="One doctor")
def get_doctor(doctor_id: int, db: sqlite3.Connection = Depends(get_db), _actor: dict = Depends(get_actor)):
    return services.get_doctor(db, doctor_id)


@router.patch("/{doctor_id}", response_model=DoctorOut, summary="Edit a doctor (admin: everything, doctor: own bio)")
def update_doctor(doctor_id: int, body: DoctorUpdateIn, db: sqlite3.Connection = Depends(get_db),
                  actor: dict = Depends(get_actor)):
    return services.update_doctor(db, actor, doctor_id, body.model_dump(exclude_unset=True))


@router.delete("/{doctor_id}", status_code=204, summary="Delete a doctor who has no appointments")
def delete_doctor(doctor_id: int, db: sqlite3.Connection = Depends(get_db), _admin: dict = Depends(admin_only)):
    services.delete_doctor(db, doctor_id)
    return Response(status_code=204)


@router.put("/{doctor_id}/schedule", response_model=DoctorOut, summary="Replace the weekly working hours")
def set_schedule(doctor_id: int, body: list[ScheduleItem], db: sqlite3.Connection = Depends(get_db),
                 actor: dict = Depends(get_actor)):
    return services.set_schedule(db, actor, doctor_id, [item.as_dict() for item in body])


@router.get("/{doctor_id}/slots", response_model=SlotsOut, summary="Open and taken time slots on a date")
def slots(
    doctor_id: int,
    date: dt.date = Query(..., description="YYYY-MM-DD"),
    db: sqlite3.Connection = Depends(get_db),
    _actor: dict = Depends(get_actor),
):
    return services.available_slots(db, doctor_id, date)


@router.get("/{doctor_id}/leaves", response_model=list[LeaveOut], summary="Upcoming days off")
def leaves(doctor_id: int, db: sqlite3.Connection = Depends(get_db), _actor: dict = Depends(get_actor)):
    return services.list_leaves(db, doctor_id)


@router.post("/{doctor_id}/leaves", response_model=LeaveOut, status_code=201, summary="Mark a day off")
def add_leave(doctor_id: int, body: LeaveIn, db: sqlite3.Connection = Depends(get_db),
              actor: dict = Depends(get_actor)):
    return services.add_leave(db, actor, doctor_id, body.date, body.reason)


@router.delete("/{doctor_id}/leaves/{leave_date}", status_code=204, summary="Remove a day off")
def remove_leave(doctor_id: int, leave_date: dt.date, db: sqlite3.Connection = Depends(get_db),
                 actor: dict = Depends(get_actor)):
    services.remove_leave(db, actor, doctor_id, leave_date)
    return Response(status_code=204)
