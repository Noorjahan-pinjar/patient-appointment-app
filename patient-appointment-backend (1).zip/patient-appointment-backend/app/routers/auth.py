import sqlite3

from fastapi import APIRouter, Depends
from fastapi.security import OAuth2PasswordRequestForm

from .. import security, services
from ..db import get_db
from ..deps import get_actor
from ..schemas import (
    ChangePasswordIn,
    LoginIn,
    MessageOut,
    RegisterIn,
    TokenOut,
    UserOut,
    UserUpdateIn,
)

router = APIRouter(prefix="/auth", tags=["Auth"])


@router.post("/register", response_model=UserOut, status_code=201, summary="Create a patient account")
def register(body: RegisterIn, db: sqlite3.Connection = Depends(get_db)):
    return services.register_patient(
        db, username=body.username, password=body.password, full_name=body.full_name,
        email=body.email, phone=body.phone,
    )


@router.post("/login", response_model=TokenOut, summary="Log in with JSON")
def login(body: LoginIn, db: sqlite3.Connection = Depends(get_db)):
    user = services.authenticate(db, body.username, body.password)
    token, seconds = security.create_token(user["id"], user["role"])
    return {"access_token": token, "token_type": "bearer", "expires_in": seconds, "user": user}


@router.post("/token", include_in_schema=True, summary="Log in with a form (used by the Authorize button)")
def token_form(form: OAuth2PasswordRequestForm = Depends(), db: sqlite3.Connection = Depends(get_db)):
    user = services.authenticate(db, form.username, form.password)
    token, _seconds = security.create_token(user["id"], user["role"])
    return {"access_token": token, "token_type": "bearer"}


@router.get("/me", response_model=UserOut, summary="Who am I")
def me(actor: dict = Depends(get_actor), db: sqlite3.Connection = Depends(get_db)):
    return services.get_user(db, actor["id"])


@router.patch("/me", response_model=UserOut, summary="Update my name, email or phone")
def update_me(body: UserUpdateIn, actor: dict = Depends(get_actor), db: sqlite3.Connection = Depends(get_db)):
    return services.update_user(db, actor["id"], body.model_dump(exclude_unset=True))


@router.post("/change-password", response_model=MessageOut)
def change_password(body: ChangePasswordIn, actor: dict = Depends(get_actor),
                    db: sqlite3.Connection = Depends(get_db)):
    services.change_password(db, actor["id"], body.current_password, body.new_password)
    return {"message": "Password changed."}
