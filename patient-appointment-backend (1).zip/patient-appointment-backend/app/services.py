"""All business rules live here. This file does not import FastAPI, so it is easy to test.

Every public function takes an open sqlite3 connection (`db`) and, where permissions matter,
an `actor`: the logged-in user as a dict with keys id, role and (for doctors) doctor_id.
Problems are raised as DomainError(status_code, message).
"""
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from typing import Optional

from . import security
from .config import now, settings, today
from .errors import DomainError

BOOKED, COMPLETED, CANCELLED, NO_SHOW = "Booked", "Completed", "Cancelled", "NoShow"
STATUSES = (BOOKED, COMPLETED, CANCELLED, NO_SHOW)
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


# ------------------------------------------------------------------ helpers

@contextmanager
def tx(db: sqlite3.Connection):
    """Commit if the block works, roll everything back if it fails."""
    try:
        yield
        db.commit()
    except BaseException:
        db.rollback()
        raise


def _clean(value):
    if isinstance(value, str):
        value = value.strip()
        return value or None
    return value


def _stamp() -> str:
    return now().isoformat(timespec="seconds")


def _to_min(hhmm: str) -> int:
    hours, minutes = hhmm.split(":")
    return int(hours) * 60 + int(minutes)


def _fmt(minutes: int) -> str:
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def _start_dt(date_str: str, time_str: str) -> datetime:
    return datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M")


def _paging(limit: int, offset: int) -> tuple:
    return max(1, min(int(limit), 100)), max(0, int(offset))


def _in_clause(values) -> str:
    return ",".join("?" for _ in values)


# -------------------------------------------------------------------- users

USER_COLS = "id, username, full_name, role, email, phone, is_active, created_at"


def _user_dict(row) -> dict:
    data = dict(row)
    data.pop("password_hash", None)
    data["is_active"] = bool(data["is_active"])
    return data


def insert_user(db, *, username, password, full_name, role, email, phone) -> int:
    """Insert one user row. Does not commit, so callers can group it with other writes."""
    try:
        cur = db.execute(
            "INSERT INTO users (username, full_name, password_hash, role, email, phone, is_active, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, 1, ?)",
            (username.strip().lower(), full_name.strip(), security.hash_password(password),
             role, _clean(email), _clean(phone), _stamp()),
        )
    except sqlite3.IntegrityError as exc:
        if "email" in str(exc).lower():
            raise DomainError(409, "That email is already registered.")
        raise DomainError(409, "That username is already taken.")
    return cur.lastrowid


def get_user(db, user_id: int) -> dict:
    row = db.execute(f"SELECT {USER_COLS} FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None:
        raise DomainError(404, "User not found.")
    return _user_dict(row)


def register_patient(db, *, username, password, full_name, email=None, phone=None) -> dict:
    with tx(db):
        uid = insert_user(db, username=username, password=password, full_name=full_name,
                          role="patient", email=email, phone=phone)
        db.execute("INSERT INTO patients (user_id) VALUES (?)", (uid,))
    return get_user(db, uid)


def authenticate(db, username: str, password: str) -> dict:
    uname = username.strip().lower()
    if security.is_locked(uname):
        raise DomainError(429, "Too many failed attempts. Please try again in 15 minutes.")
    row = db.execute("SELECT * FROM users WHERE username = ?", (uname,)).fetchone()
    if row is None or not security.verify_password(password, row["password_hash"]):
        security.record_failure(uname)
        raise DomainError(401, "Wrong username or password.")
    if not row["is_active"]:
        raise DomainError(403, "This account is disabled. Please contact the hospital.")
    security.clear_failures(uname)
    return _user_dict(row)


def actor_for(db, user: dict) -> dict:
    """The logged-in user plus doctor_id when the user is a doctor."""
    actor = dict(user)
    actor["doctor_id"] = None
    if user["role"] == "doctor":
        row = db.execute("SELECT id FROM doctors WHERE user_id = ?", (user["id"],)).fetchone()
        actor["doctor_id"] = row["id"] if row else None
    return actor


def user_from_token(db, token: str) -> Optional[dict]:
    user_id = security.decode_token(token)
    if user_id is None:
        return None
    row = db.execute(f"SELECT {USER_COLS} FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None or not row["is_active"]:
        return None
    return actor_for(db, _user_dict(row))


def change_password(db, user_id: int, current: str, new: str) -> None:
    row = db.execute("SELECT password_hash FROM users WHERE id = ?", (user_id,)).fetchone()
    if row is None or not security.verify_password(current, row["password_hash"]):
        raise DomainError(400, "Your current password is wrong.")
    if current == new:
        raise DomainError(400, "The new password must be different from the current one.")
    with tx(db):
        db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (security.hash_password(new), user_id))


def update_user(db, user_id: int, data: dict) -> dict:
    sets, values = [], []
    for key in ("full_name", "email", "phone"):
        if key in data:
            sets.append(f"{key} = ?")
            values.append(_clean(data[key]))
    if sets:
        try:
            with tx(db):
                db.execute(f"UPDATE users SET {', '.join(sets)} WHERE id = ?", (*values, user_id))
        except sqlite3.IntegrityError:
            raise DomainError(409, "That email is already registered.")
    return get_user(db, user_id)


def list_users(db, *, role=None, q=None, is_active=None, limit=20, offset=0) -> tuple:
    limit, offset = _paging(limit, offset)
    where, params = ["1=1"], []
    if role:
        where.append("role = ?")
        params.append(role)
    if is_active is not None:
        where.append("is_active = ?")
        params.append(1 if is_active else 0)
    if q:
        where.append("(LOWER(full_name) LIKE ? OR username LIKE ? OR LOWER(COALESCE(email, '')) LIKE ?)")
        like = f"%{q.strip().lower()}%"
        params += [like, like, like]
    clause = " AND ".join(where)
    total = db.execute(f"SELECT COUNT(*) FROM users WHERE {clause}", params).fetchone()[0]
    rows = db.execute(
        f"SELECT {USER_COLS} FROM users WHERE {clause} ORDER BY full_name LIMIT ? OFFSET ?",
        (*params, limit, offset),
    ).fetchall()
    return [_user_dict(r) for r in rows], total


def set_user_active(db, actor: dict, user_id: int, active: bool) -> dict:
    if user_id == actor["id"] and not active:
        raise DomainError(400, "You cannot disable your own account.")
    get_user(db, user_id)
    with tx(db):
        db.execute("UPDATE users SET is_active = ? WHERE id = ?", (1 if active else 0, user_id))
    return get_user(db, user_id)


# ----------------------------------------------------------------- patients

PROFILE_FIELDS = ("dob", "gender", "blood_group", "address", "emergency_contact")


def _patient_dict(db, user_id: int) -> dict:
    user = get_user(db, user_id)
    if user["role"] != "patient":
        raise DomainError(404, "Patient not found.")
    row = db.execute(
        "SELECT dob, gender, blood_group, address, emergency_contact FROM patients WHERE user_id = ?",
        (user_id,),
    ).fetchone()
    user.update(dict(row) if row else {f: None for f in PROFILE_FIELDS})
    return user


def _doctor_has_seen(db, doctor_id: int, patient_id: int) -> bool:
    return db.execute(
        "SELECT 1 FROM appointments WHERE doctor_id = ? AND patient_id = ? LIMIT 1", (doctor_id, patient_id)
    ).fetchone() is not None


def get_patient(db, actor: dict, patient_id: int) -> dict:
    role = actor["role"]
    allowed = (
        role == "admin"
        or (role == "patient" and actor["id"] == patient_id)
        or (role == "doctor" and _doctor_has_seen(db, actor["doctor_id"], patient_id))
    )
    if not allowed:
        raise DomainError(404, "Patient not found.")
    return _patient_dict(db, patient_id)


def update_patient_profile(db, patient_id: int, data: dict) -> dict:
    _patient_dict(db, patient_id)  # 404 if this is not a patient
    sets, values = [], []
    for key in PROFILE_FIELDS:
        if key in data:
            value = data[key]
            if isinstance(value, date):
                value = value.isoformat()
            sets.append(f"{key} = ?")
            values.append(_clean(value))
    with tx(db):
        db.execute("INSERT OR IGNORE INTO patients (user_id) VALUES (?)", (patient_id,))
        if sets:
            db.execute(f"UPDATE patients SET {', '.join(sets)} WHERE user_id = ?", (*values, patient_id))
    return _patient_dict(db, patient_id)


def list_patients(db, actor: dict, *, q=None, limit=20, offset=0) -> tuple:
    limit, offset = _paging(limit, offset)
    where, params = ["u.role = 'patient'"], []
    if actor["role"] == "doctor":
        where.append("u.id IN (SELECT patient_id FROM appointments WHERE doctor_id = ?)")
        params.append(actor["doctor_id"])
    if q:
        where.append("(LOWER(u.full_name) LIKE ? OR u.username LIKE ? OR COALESCE(u.phone, '') LIKE ?)")
        like = f"%{q.strip().lower()}%"
        params += [like, like, like]
    clause = " AND ".join(where)
    total = db.execute(f"SELECT COUNT(*) FROM users u WHERE {clause}", params).fetchone()[0]
    rows = db.execute(
        f"SELECT u.id FROM users u WHERE {clause} ORDER BY u.full_name LIMIT ? OFFSET ?",
        (*params, limit, offset),
    ).fetchall()
    return [_patient_dict(db, r["id"]) for r in rows], total


# ------------------------------------------------------------------ doctors

DOCTOR_SELECT = """
    SELECT d.id, d.user_id, u.full_name, u.username, u.email, u.phone,
           d.specialization, d.experience_years, d.consultation_fee, d.bio,
           d.slot_minutes, (d.is_active AND u.is_active) AS is_active
    FROM doctors d JOIN users u ON u.id = d.user_id
"""


def _doctor_dict(db, row) -> dict:
    data = dict(row)
    data["is_active"] = bool(data["is_active"])
    data["consultation_fee"] = float(data["consultation_fee"])
    schedule = db.execute(
        "SELECT weekday, start_time, end_time FROM doctor_schedules WHERE doctor_id = ? "
        "ORDER BY weekday, start_time",
        (data["id"],),
    ).fetchall()
    data["schedule"] = [{**dict(s), "day": DAY_NAMES[s["weekday"]]} for s in schedule]
    return data


def get_doctor(db, doctor_id: int) -> dict:
    row = db.execute(DOCTOR_SELECT + " WHERE d.id = ?", (doctor_id,)).fetchone()
    if row is None:
        raise DomainError(404, "Doctor not found.")
    return _doctor_dict(db, row)


def list_doctors(db, *, specialization=None, q=None, include_inactive=False, limit=50, offset=0) -> tuple:
    limit, offset = _paging(limit, offset)
    where, params = ["1=1"], []
    if not include_inactive:
        where.append("d.is_active = 1 AND u.is_active = 1")
    if specialization:
        where.append("LOWER(d.specialization) = LOWER(?)")
        params.append(specialization.strip())
    if q:
        where.append("(LOWER(u.full_name) LIKE ? OR LOWER(d.specialization) LIKE ?)")
        like = f"%{q.strip().lower()}%"
        params += [like, like]
    clause = " AND ".join(where)
    total = db.execute(
        f"SELECT COUNT(*) FROM doctors d JOIN users u ON u.id = d.user_id WHERE {clause}", params
    ).fetchone()[0]
    rows = db.execute(
        DOCTOR_SELECT + f" WHERE {clause} ORDER BY u.full_name LIMIT ? OFFSET ?", (*params, limit, offset)
    ).fetchall()
    return [_doctor_dict(db, r) for r in rows], total


def list_specializations(db) -> list:
    rows = db.execute(
        "SELECT DISTINCT d.specialization FROM doctors d JOIN users u ON u.id = d.user_id "
        "WHERE d.is_active = 1 AND u.is_active = 1 ORDER BY d.specialization"
    ).fetchall()
    return [r[0] for r in rows]


def _validate_schedule(items: list, slot_minutes: int) -> None:
    by_day: dict = {}
    for item in items:
        start, end = _to_min(item["start_time"]), _to_min(item["end_time"])
        if end - start < slot_minutes:
            raise DomainError(422, f"Each working period must be at least {slot_minutes} minutes long.")
        by_day.setdefault(item["weekday"], []).append((start, end))
    for spans in by_day.values():
        spans.sort()
        for first, second in zip(spans, spans[1:]):
            if second[0] < first[1]:
                raise DomainError(422, "Working periods on the same day must not overlap.")


def _write_schedule(db, doctor_id: int, items: list) -> None:
    db.execute("DELETE FROM doctor_schedules WHERE doctor_id = ?", (doctor_id,))
    db.executemany(
        "INSERT INTO doctor_schedules (doctor_id, weekday, start_time, end_time) VALUES (?, ?, ?, ?)",
        [(doctor_id, i["weekday"], i["start_time"], i["end_time"]) for i in items],
    )


def create_doctor(db, data: dict) -> dict:
    slot = data.get("slot_minutes", 30)
    schedule = data.get("schedule", [])
    _validate_schedule(schedule, slot)
    with tx(db):
        uid = insert_user(
            db, username=data["username"], password=data["password"], full_name=data["full_name"],
            role="doctor", email=data.get("email"), phone=data.get("phone"),
        )
        cur = db.execute(
            "INSERT INTO doctors (user_id, specialization, experience_years, consultation_fee, bio, slot_minutes) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (uid, data["specialization"].strip(), data.get("experience_years", 0),
             data.get("consultation_fee", 0), _clean(data.get("bio")), slot),
        )
        doctor_id = cur.lastrowid
        _write_schedule(db, doctor_id, schedule)
    return get_doctor(db, doctor_id)


def _can_manage_doctor(actor: dict, doctor_id: int) -> bool:
    return actor["role"] == "admin" or (actor["role"] == "doctor" and actor["doctor_id"] == doctor_id)


def _future_booked_count(db, doctor_id: int, on_date: Optional[str] = None) -> int:
    if on_date:
        sql, params = "date = ?", (on_date,)
    else:
        sql, params = "(date || ' ' || time) >= ?", (now().strftime("%Y-%m-%d %H:%M"),)
    return db.execute(
        f"SELECT COUNT(*) FROM appointments WHERE doctor_id = ? AND status = 'Booked' AND {sql}",
        (doctor_id, *params),
    ).fetchone()[0]


def update_doctor(db, actor: dict, doctor_id: int, data: dict) -> dict:
    doc = get_doctor(db, doctor_id)
    if not _can_manage_doctor(actor, doctor_id):
        raise DomainError(403, "You cannot change this doctor.")
    if actor["role"] != "admin":
        extra = set(data) - {"bio", "experience_years", "phone"}
        if extra:
            raise DomainError(403, f"Only the admin can change: {', '.join(sorted(extra))}.")

    if "slot_minutes" in data and data["slot_minutes"] != doc["slot_minutes"]:
        if _future_booked_count(db, doctor_id):
            raise DomainError(409, "Slot length cannot change while there are upcoming booked appointments.")
        _validate_schedule(doc["schedule"], data["slot_minutes"])

    doctor_sets, doctor_values = [], []
    for key in ("specialization", "experience_years", "consultation_fee", "bio", "slot_minutes"):
        if key in data:
            doctor_sets.append(f"{key} = ?")
            doctor_values.append(_clean(data[key]))
    if "is_active" in data:
        doctor_sets.append("is_active = ?")
        doctor_values.append(1 if data["is_active"] else 0)

    with tx(db):
        if doctor_sets:
            db.execute(f"UPDATE doctors SET {', '.join(doctor_sets)} WHERE id = ?", (*doctor_values, doctor_id))
        user_sets, user_values = [], []
        for key in ("full_name", "email", "phone"):
            if key in data:
                user_sets.append(f"{key} = ?")
                user_values.append(_clean(data[key]))
        if user_sets:
            try:
                db.execute(f"UPDATE users SET {', '.join(user_sets)} WHERE id = ?", (*user_values, doc["user_id"]))
            except sqlite3.IntegrityError:
                raise DomainError(409, "That email is already registered.")
    return get_doctor(db, doctor_id)


def set_schedule(db, actor: dict, doctor_id: int, items: list) -> dict:
    doc = get_doctor(db, doctor_id)
    if not _can_manage_doctor(actor, doctor_id):
        raise DomainError(403, "You cannot change this doctor's schedule.")
    _validate_schedule(items, doc["slot_minutes"])
    with tx(db):
        _write_schedule(db, doctor_id, items)
    return get_doctor(db, doctor_id)


def delete_doctor(db, doctor_id: int) -> None:
    doc = get_doctor(db, doctor_id)
    used = db.execute("SELECT 1 FROM appointments WHERE doctor_id = ? LIMIT 1", (doctor_id,)).fetchone()
    if used:
        raise DomainError(409, "This doctor has appointment history. Disable the doctor instead of deleting.")
    with tx(db):
        db.execute("DELETE FROM doctors WHERE id = ?", (doctor_id,))
        db.execute("DELETE FROM users WHERE id = ?", (doc["user_id"],))


# ------------------------------------------------------------ doctor leaves

def list_leaves(db, doctor_id: int) -> list:
    get_doctor(db, doctor_id)
    rows = db.execute(
        "SELECT date, reason FROM doctor_leaves WHERE doctor_id = ? AND date >= ? ORDER BY date",
        (doctor_id, today().isoformat()),
    ).fetchall()
    return [dict(r) for r in rows]


def add_leave(db, actor: dict, doctor_id: int, on_date: date, reason: Optional[str]) -> dict:
    get_doctor(db, doctor_id)
    if not _can_manage_doctor(actor, doctor_id):
        raise DomainError(403, "You cannot change this doctor's leave.")
    if on_date < today():
        raise DomainError(400, "Leave cannot be added for a past date.")
    booked = _future_booked_count(db, doctor_id, on_date.isoformat())
    if booked:
        raise DomainError(409, f"{booked} appointment(s) are booked on that day. Cancel or reschedule them first.")
    try:
        with tx(db):
            db.execute(
                "INSERT INTO doctor_leaves (doctor_id, date, reason) VALUES (?, ?, ?)",
                (doctor_id, on_date.isoformat(), _clean(reason)),
            )
    except sqlite3.IntegrityError:
        raise DomainError(409, "That day is already marked as leave.")
    return {"date": on_date.isoformat(), "reason": _clean(reason)}


def remove_leave(db, actor: dict, doctor_id: int, on_date: date) -> None:
    get_doctor(db, doctor_id)
    if not _can_manage_doctor(actor, doctor_id):
        raise DomainError(403, "You cannot change this doctor's leave.")
    with tx(db):
        cur = db.execute(
            "DELETE FROM doctor_leaves WHERE doctor_id = ? AND date = ?", (doctor_id, on_date.isoformat())
        )
    if cur.rowcount == 0:
        raise DomainError(404, "No leave is set on that date.")


# -------------------------------------------------------------------- slots

def _day_slots(db, doc: dict, on_date: date) -> list:
    """Every slot the doctor works on this date (booked or not). Empty for past days and leave days."""
    if on_date < today():
        return []
    if db.execute(
        "SELECT 1 FROM doctor_leaves WHERE doctor_id = ? AND date = ?", (doc["id"], on_date.isoformat())
    ).fetchone():
        return []
    slot = doc["slot_minutes"]
    slots = set()
    for period in doc["schedule"]:
        if period["weekday"] != on_date.weekday():
            continue
        cursor, end = _to_min(period["start_time"]), _to_min(period["end_time"])
        while cursor + slot <= end:
            slots.add(_fmt(cursor))
            cursor += slot
    return sorted(slots)


def _slot_taken(db, doctor_id: int, date_str: str, time_str: str, exclude_id: Optional[int] = None) -> bool:
    row = db.execute(
        "SELECT 1 FROM appointments WHERE doctor_id = ? AND date = ? AND time = ? AND status <> 'Cancelled' "
        "AND id <> ?",
        (doctor_id, date_str, time_str, exclude_id or 0),
    ).fetchone()
    return row is not None


def available_slots(db, doctor_id: int, on_date: date) -> dict:
    doc = get_doctor(db, doctor_id)
    slots = []
    if doc["is_active"]:
        booked = {
            r["time"] for r in db.execute(
                "SELECT time FROM appointments WHERE doctor_id = ? AND date = ? AND status <> 'Cancelled'",
                (doctor_id, on_date.isoformat()),
            )
        }
        current = now()
        for t in _day_slots(db, doc, on_date):
            in_past = _start_dt(on_date.isoformat(), t) <= current
            slots.append({"time": t, "available": t not in booked and not in_past})
    return {
        "doctor_id": doctor_id, "date": on_date.isoformat(),
        "slot_minutes": doc["slot_minutes"], "slots": slots,
    }


def _validate_slot(db, doc: dict, on_date: date, time_str: str, exclude_id: Optional[int] = None) -> None:
    if on_date < today():
        raise DomainError(400, "That date has already passed.")
    if on_date > today() + timedelta(days=settings.max_advance_days):
        raise DomainError(400, f"Appointments can only be booked up to {settings.max_advance_days} days ahead.")
    if time_str not in _day_slots(db, doc, on_date):
        raise DomainError(
            400, "The doctor is not available at that time (outside working hours, not a slot start, or on leave)."
        )
    if _start_dt(on_date.isoformat(), time_str) <= now():
        raise DomainError(400, "That time has already passed. Pick a later slot.")
    if _slot_taken(db, doc["id"], on_date.isoformat(), time_str, exclude_id):
        raise DomainError(409, "This doctor is already booked at that time. Pick another slot.")


def _conflict(exc: sqlite3.IntegrityError) -> DomainError:
    text = str(exc).lower()
    if "patient_id" in text:
        return DomainError(409, "This patient already has an appointment at that time.")
    return DomainError(409, "This doctor is already booked at that time. Pick another slot.")


# ------------------------------------------------------------- appointments

APPT_SELECT = """
    SELECT a.id, a.patient_id, pu.full_name AS patient_name,
           a.doctor_id, du.full_name AS doctor_name, d.specialization, d.slot_minutes,
           a.date, a.time, a.status, a.reason, a.cancel_reason, a.cancelled_by,
           a.notes, a.diagnosis, a.prescription, a.created_at, a.updated_at
    FROM appointments a
    JOIN users   pu ON pu.id = a.patient_id
    JOIN doctors d  ON d.id  = a.doctor_id
    JOIN users   du ON du.id = d.user_id
"""


def _appt_dict(row) -> dict:
    data = dict(row)
    data["end_time"] = _fmt(_to_min(data["time"]) + data.pop("slot_minutes"))
    return data


def _get_appt(db, appt_id: int) -> dict:
    row = db.execute(APPT_SELECT + " WHERE a.id = ?", (appt_id,)).fetchone()
    if row is None:
        raise DomainError(404, "Appointment not found.")
    return _appt_dict(row)


def get_appointment(db, actor: dict, appt_id: int) -> dict:
    appt = _get_appt(db, appt_id)
    role = actor["role"]
    allowed = (
        role == "admin"
        or (role == "patient" and appt["patient_id"] == actor["id"])
        or (role == "doctor" and appt["doctor_id"] == actor["doctor_id"])
    )
    if not allowed:
        raise DomainError(404, "Appointment not found.")  # do not reveal that it exists
    return appt


def book_appointment(db, actor: dict, *, doctor_id: int, on_date: date, time_str: str,
                     reason: Optional[str] = None, patient_id: Optional[int] = None) -> dict:
    if actor["role"] == "patient":
        pid = actor["id"]
    elif actor["role"] == "admin":
        if not patient_id:
            raise DomainError(422, "patient_id is required when the admin books for a patient.")
        pid = patient_id
    else:
        raise DomainError(403, "Doctors cannot book appointments.")

    if db.execute(
        "SELECT 1 FROM users WHERE id = ? AND role = 'patient' AND is_active = 1", (pid,)
    ).fetchone() is None:
        raise DomainError(404, "Patient not found.")
    doc = get_doctor(db, doctor_id)
    if not doc["is_active"]:
        raise DomainError(400, "This doctor is not taking appointments right now.")

    _validate_slot(db, doc, on_date, time_str)
    try:
        with tx(db):
            cur = db.execute(
                "INSERT INTO appointments (patient_id, doctor_id, date, time, reason, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (pid, doctor_id, on_date.isoformat(), time_str, _clean(reason), _stamp(), _stamp()),
            )
    except sqlite3.IntegrityError as exc:  # two people took the slot at the same moment
        raise _conflict(exc)
    return _get_appt(db, cur.lastrowid)


def list_appointments(db, actor: dict, *, status=None, date_from=None, date_to=None, doctor_id=None,
                      patient_id=None, newest_first=False, limit=20, offset=0) -> tuple:
    limit, offset = _paging(limit, offset)
    where, params = ["1=1"], []
    role = actor["role"]

    if role == "patient":
        if patient_id and patient_id != actor["id"]:
            raise DomainError(403, "You can only see your own appointments.")
        where.append("a.patient_id = ?")
        params.append(actor["id"])
    elif role == "doctor":
        if doctor_id and doctor_id != actor["doctor_id"]:
            raise DomainError(403, "You can only see your own appointments.")
        where.append("a.doctor_id = ?")
        params.append(actor["doctor_id"])

    if doctor_id and role != "doctor":
        where.append("a.doctor_id = ?")
        params.append(doctor_id)
    if patient_id and role != "patient":
        where.append("a.patient_id = ?")
        params.append(patient_id)
    if status:
        if status not in STATUSES:
            raise DomainError(422, f"status must be one of: {', '.join(STATUSES)}.")
        where.append("a.status = ?")
        params.append(status)
    if date_from:
        where.append("a.date >= ?")
        params.append(date_from.isoformat())
    if date_to:
        where.append("a.date <= ?")
        params.append(date_to.isoformat())

    clause = " AND ".join(where)
    direction = "DESC" if newest_first else "ASC"
    total = db.execute(f"SELECT COUNT(*) FROM appointments a WHERE {clause}", params).fetchone()[0]
    rows = db.execute(
        APPT_SELECT + f" WHERE {clause} ORDER BY a.date {direction}, a.time {direction} LIMIT ? OFFSET ?",
        (*params, limit, offset),
    ).fetchall()
    return [_appt_dict(r) for r in rows], total


def cancel_appointment(db, actor: dict, appt_id: int, reason: Optional[str] = None) -> dict:
    appt = get_appointment(db, actor, appt_id)
    if appt["status"] != BOOKED:
        raise DomainError(409, f"This appointment is already {appt['status'].lower()}.")
    start = _start_dt(appt["date"], appt["time"])
    if start <= now():
        raise DomainError(400, "Past appointments cannot be cancelled.")
    if actor["role"] == "patient" and start - now() < timedelta(hours=settings.cancel_hours_before):
        raise DomainError(
            400, f"Appointments can only be cancelled at least {settings.cancel_hours_before} hours "
                 "before the visit. Please call the hospital."
        )
    with tx(db):
        db.execute(
            "UPDATE appointments SET status = 'Cancelled', cancel_reason = ?, cancelled_by = ?, updated_at = ? "
            "WHERE id = ?",
            (_clean(reason), actor["role"], _stamp(), appt_id),
        )
    return _get_appt(db, appt_id)


def reschedule_appointment(db, actor: dict, appt_id: int, new_date: date, new_time: str) -> dict:
    if actor["role"] == "doctor":
        raise DomainError(403, "Only the patient or the admin can reschedule.")
    appt = get_appointment(db, actor, appt_id)
    if appt["status"] != BOOKED:
        raise DomainError(409, f"A {appt['status'].lower()} appointment cannot be rescheduled.")
    start = _start_dt(appt["date"], appt["time"])
    if actor["role"] == "patient" and start - now() < timedelta(hours=settings.cancel_hours_before):
        raise DomainError(
            400, f"Appointments can only be changed at least {settings.cancel_hours_before} hours "
                 "before the visit. Please call the hospital."
        )
    if new_date.isoformat() == appt["date"] and new_time == appt["time"]:
        raise DomainError(400, "That is the same date and time as the current appointment.")

    doc = get_doctor(db, appt["doctor_id"])
    if not doc["is_active"]:
        raise DomainError(400, "This doctor is not taking appointments right now.")
    _validate_slot(db, doc, new_date, new_time, exclude_id=appt_id)
    try:
        with tx(db):
            db.execute(
                "UPDATE appointments SET date = ?, time = ?, updated_at = ? WHERE id = ?",
                (new_date.isoformat(), new_time, _stamp(), appt_id),
            )
    except sqlite3.IntegrityError as exc:
        raise _conflict(exc)
    return _get_appt(db, appt_id)


def _doctor_or_admin_for(db, actor: dict, appt_id: int) -> dict:
    if actor["role"] == "patient":
        raise DomainError(403, "Only the doctor or the admin can do this.")
    return get_appointment(db, actor, appt_id)


def complete_appointment(db, actor: dict, appt_id: int, *, notes=None, diagnosis=None, prescription=None) -> dict:
    appt = _doctor_or_admin_for(db, actor, appt_id)
    if appt["status"] != BOOKED:
        raise DomainError(409, f"This appointment is already {appt['status'].lower()}.")
    if appt["date"] > today().isoformat():
        raise DomainError(400, "An appointment can only be completed on or after its day.")
    with tx(db):
        db.execute(
            "UPDATE appointments SET status = 'Completed', notes = ?, diagnosis = ?, prescription = ?, "
            "updated_at = ? WHERE id = ?",
            (_clean(notes), _clean(diagnosis), _clean(prescription), _stamp(), appt_id),
        )
    return _get_appt(db, appt_id)


def mark_no_show(db, actor: dict, appt_id: int) -> dict:
    appt = _doctor_or_admin_for(db, actor, appt_id)
    if appt["status"] != BOOKED:
        raise DomainError(409, f"This appointment is already {appt['status'].lower()}.")
    if _start_dt(appt["date"], appt["time"]) > now():
        raise DomainError(400, "An appointment can only be marked no-show after its start time.")
    with tx(db):
        db.execute(
            "UPDATE appointments SET status = 'NoShow', updated_at = ? WHERE id = ?", (_stamp(), appt_id)
        )
    return _get_appt(db, appt_id)


# ---------------------------------------------------------------- dashboard

def _count(db, sql: str, params=()) -> int:
    return db.execute(sql, params).fetchone()[0]


def dashboard_summary(db, actor: dict) -> dict:
    role = actor["role"]
    stamp = now().strftime("%Y-%m-%d %H:%M")
    today_s = today().isoformat()

    if role == "patient":
        where, params = "a.patient_id = ?", [actor["id"]]
    elif role == "doctor":
        where, params = "a.doctor_id = ?", [actor["doctor_id"]]
    else:
        where, params = "1=1", []

    def n(extra: str = "", more=()) -> int:
        return _count(db, f"SELECT COUNT(*) FROM appointments a WHERE {where} {extra}", (*params, *more))

    upcoming_sql = "AND a.status = 'Booked' AND (a.date || ' ' || a.time) >= ?"
    summary = {
        "role": role,
        "hospital_name": settings.hospital_name,
        "total_appointments": n(),
        "upcoming": n(upcoming_sql, (stamp,)),
        "today": n("AND a.status <> 'Cancelled' AND a.date = ?", (today_s,)),
        "completed": n("AND a.status = 'Completed'"),
        "cancelled": n("AND a.status = 'Cancelled'"),
        "no_show": n("AND a.status = 'NoShow'"),
        "needs_update": n("AND a.status = 'Booked' AND (a.date || ' ' || a.time) < ?", (stamp,)),
        "total_doctors": _count(db, "SELECT COUNT(*) FROM doctors WHERE is_active = 1"),
    }

    def rows(extra: str, more=(), order="ASC", limit=8) -> list:
        found = db.execute(
            APPT_SELECT + f" WHERE {where} {extra} ORDER BY a.date {order}, a.time {order} LIMIT {limit}",
            (*params, *more),
        ).fetchall()
        return [_appt_dict(r) for r in found]

    summary["upcoming_appointments"] = rows(upcoming_sql, (stamp,))
    summary["next_appointment"] = summary["upcoming_appointments"][0] if summary["upcoming_appointments"] else None
    summary["todays_appointments"] = rows("AND a.status <> 'Cancelled' AND a.date = ?", (today_s,), limit=50)
    summary["recent_appointments"] = rows("", order="DESC")

    if role == "doctor":
        summary["patients_seen"] = _count(
            db, "SELECT COUNT(DISTINCT patient_id) FROM appointments WHERE doctor_id = ? AND status = 'Completed'",
            (actor["doctor_id"],),
        )
    if role == "admin":
        summary["total_patients"] = _count(db, "SELECT COUNT(*) FROM users WHERE role = 'patient'")
        summary["by_status"] = {
            r["status"]: r["c"] for r in db.execute("SELECT status, COUNT(*) AS c FROM appointments GROUP BY status")
        }
        summary["by_specialization"] = [dict(r) for r in db.execute(
            "SELECT d.specialization, COUNT(*) AS appointments FROM appointments a "
            "JOIN doctors d ON d.id = a.doctor_id WHERE a.status <> 'Cancelled' "
            "GROUP BY d.specialization ORDER BY appointments DESC"
        )]
        summary["busiest_doctors"] = [dict(r) for r in db.execute(
            "SELECT du.full_name AS doctor_name, d.specialization, COUNT(*) AS appointments "
            "FROM appointments a JOIN doctors d ON d.id = a.doctor_id JOIN users du ON du.id = d.user_id "
            "WHERE a.status <> 'Cancelled' GROUP BY d.id ORDER BY appointments DESC, doctor_name LIMIT 5"
        )]
        first_day = today() - timedelta(days=6)
        per_day = {
            r["date"]: r["c"] for r in db.execute(
                "SELECT date, COUNT(*) AS c FROM appointments WHERE status <> 'Cancelled' AND date >= ? "
                "GROUP BY date", (first_day.isoformat(),),
            )
        }
        summary["last_7_days"] = [
            {"date": (first_day + timedelta(days=i)).isoformat(),
             "appointments": per_day.get((first_day + timedelta(days=i)).isoformat(), 0)}
            for i in range(7)
        ]
    return summary
