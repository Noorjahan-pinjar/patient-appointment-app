from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .config import settings
from .db import init_db
from .errors import DomainError
from .routers import appointments, auth, dashboard, doctors, patients, users


@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title=f"{settings.hospital_name} - Patient Appointment API",
    version="2.0.0",
    description="Patients book visits, doctors manage their day, the admin runs the hospital.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(DomainError)
async def domain_error_handler(_request: Request, exc: DomainError):
    headers = {"WWW-Authenticate": "Bearer"} if exc.status_code == 401 else None
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail}, headers=headers)


for module in (auth, users, patients, doctors, appointments, dashboard):
    app.include_router(module.router)


@app.get("/", tags=["Health"])
def root():
    return {"app": "Patient Appointment API", "hospital": settings.hospital_name, "docs": "/docs"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
