"""Request and response shapes. Pydantic checks every request against these before our code runs."""
import datetime as dt
import re
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator

FIRST_NAME_RE = re.compile(r"^[A-Za-z0-9_.]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^[0-9+()\-\s]{7,20}$")
BLOOD_GROUPS = ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")


def _check_password(value: str) -> str:
    if len(value) < 8 or not re.search(r"[A-Za-z]", value) or not re.search(r"\d", value):
        raise ValueError("Password must be at least 8 characters and contain a letter and a number.")
    return value


def _check_email(value: Optional[str]) -> Optional[str]:
    if value in (None, ""):
        return None
    if not EMAIL_RE.match(value):
        raise ValueError("Enter a valid email address.")
    return value


def _check_phone(value: Optional[str]) -> Optional[str]:
    if value in (None, ""):
        return None
    if not PHONE_RE.match(value):
        raise ValueError("Enter a valid phone number.")
    return value


def _check_username(value: str) -> str:
    if not FIRST_NAME_RE.match(value):
        raise ValueError("Username must be 3-30 characters: letters, numbers, dot or underscore.")
    return value


# --------------------------------------------------------------------- auth

class RegisterIn(BaseModel):
    username: str
    password: str
    full_name: str = Field(min_length=2, max_length=60)
    email: Optional[str] = None
    phone: Optional[str] = None

    _u = field_validator("username")(_check_username)
    _p = field_validator("password")(_check_password)
    _e = field_validator("email")(_check_email)
    _ph = field_validator("phone")(_check_phone)


class LoginIn(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    id: int
    username: str
    full_name: str
    role: str
    email: Optional[str] = None
    phone: Optional[str] = None
    is_active: bool
    created_at: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    user: UserOut


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str

    _p = field_validator("new_password")(_check_password)


class UserUpdateIn(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=2, max_length=60)
    email: Optional[str] = None
    phone: Optional[str] = None

    _e = field_validator("email")(_check_email)
    _ph = field_validator("phone")(_check_phone)


class ActiveIn(BaseModel):
    is_active: bool


class MessageOut(BaseModel):
    message: str


# ----------------------------------------------------------------- patients

class PatientProfileIn(BaseModel):
    dob: Optional[dt.date] = None
    gender: Optional[Literal["Male", "Female", "Other"]] = None
    blood_group: Optional[str] = None
    address: Optional[str] = Field(default=None, max_length=300)
    emergency_contact: Optional[str] = Field(default=None, max_length=100)

    @field_validator("dob")
    @classmethod
    def not_future(cls, value):
        if value and value > dt.date.today():
            raise ValueError("Date of birth cannot be in the future.")
        return value

    @field_validator("blood_group")
    @classmethod
    def valid_group(cls, value):
        if value is not None and value not in BLOOD_GROUPS:
            raise ValueError(f"Blood group must be one of: {', '.join(BLOOD_GROUPS)}.")
        return value


class PatientOut(UserOut):
    dob: Optional[str] = None
    gender: Optional[str] = None
    blood_group: Optional[str] = None
    address: Optional[str] = None
    emergency_contact: Optional[str] = None


class PatientPage(BaseModel):
    items: list[PatientOut]
    total: int
    limit: int
    offset: int


class UserPage(BaseModel):
    items: list[UserOut]
    total: int
    limit: int
    offset: int


# ------------------------------------------------------------------ doctors

SLOT_LENGTHS = Literal[10, 15, 20, 30, 45, 60]


class ScheduleItem(BaseModel):
    weekday: int = Field(ge=0, le=6, description="0 = Monday ... 6 = Sunday")
    start_time: dt.time
    end_time: dt.time

    @model_validator(mode="after")
    def check_order(self):
        if self.start_time.second or self.end_time.second:
            raise ValueError("Use whole minutes, for example 09:00.")
        if self.end_time <= self.start_time:
            raise ValueError("end_time must be after start_time.")
        return self

    def as_dict(self) -> dict:
        return {
            "weekday": self.weekday,
            "start_time": self.start_time.strftime("%H:%M"),
            "end_time": self.end_time.strftime("%H:%M"),
        }


class ScheduleOut(BaseModel):
    weekday: int
    day: str
    start_time: str
    end_time: str


class DoctorCreateIn(BaseModel):
    username: str
    password: str
    full_name: str = Field(min_length=2, max_length=60)
    email: Optional[str] = None
    phone: Optional[str] = None
    specialization: str = Field(min_length=2, max_length=60)
    experience_years: int = Field(default=0, ge=0, le=70)
    consultation_fee: float = Field(default=0, ge=0)
    bio: Optional[str] = Field(default=None, max_length=500)
    slot_minutes: SLOT_LENGTHS = 30
    schedule: list[ScheduleItem] = []

    _u = field_validator("username")(_check_username)
    _p = field_validator("password")(_check_password)
    _e = field_validator("email")(_check_email)
    _ph = field_validator("phone")(_check_phone)


class DoctorUpdateIn(BaseModel):
    full_name: Optional[str] = Field(default=None, min_length=2, max_length=60)
    email: Optional[str] = None
    phone: Optional[str] = None
    specialization: Optional[str] = Field(default=None, min_length=2, max_length=60)
    experience_years: Optional[int] = Field(default=None, ge=0, le=70)
    consultation_fee: Optional[float] = Field(default=None, ge=0)
    bio: Optional[str] = Field(default=None, max_length=500)
    slot_minutes: Optional[SLOT_LENGTHS] = None
    is_active: Optional[bool] = None

    _e = field_validator("email")(_check_email)
    _ph = field_validator("phone")(_check_phone)


class DoctorOut(BaseModel):
    id: int
    user_id: int
    full_name: str
    username: str
    email: Optional[str] = None
    phone: Optional[str] = None
    specialization: str
    experience_years: int
    consultation_fee: float
    bio: Optional[str] = None
    slot_minutes: int
    is_active: bool
    schedule: list[ScheduleOut]


class DoctorPage(BaseModel):
    items: list[DoctorOut]
    total: int
    limit: int
    offset: int


class LeaveIn(BaseModel):
    date: dt.date
    reason: Optional[str] = Field(default=None, max_length=200)


class LeaveOut(BaseModel):
    date: str
    reason: Optional[str] = None


class SlotOut(BaseModel):
    time: str
    available: bool


class SlotsOut(BaseModel):
    doctor_id: int
    date: str
    slot_minutes: int
    slots: list[SlotOut]


# ------------------------------------------------------------- appointments

def _whole_minute(value: dt.time) -> dt.time:
    if value.second or value.microsecond:
        raise ValueError("Use whole minutes, for example 10:30.")
    return value


class AppointmentIn(BaseModel):
    doctor_id: int
    date: dt.date
    time: dt.time
    reason: Optional[str] = Field(default=None, max_length=300)
    patient_id: Optional[int] = Field(default=None, description="Admin only: book for this patient")

    _t = field_validator("time")(_whole_minute)


class RescheduleIn(BaseModel):
    date: dt.date
    time: dt.time

    _t = field_validator("time")(_whole_minute)


class CancelIn(BaseModel):
    reason: Optional[str] = Field(default=None, max_length=300)


class CompleteIn(BaseModel):
    notes: Optional[str] = Field(default=None, max_length=2000)
    diagnosis: Optional[str] = Field(default=None, max_length=1000)
    prescription: Optional[str] = Field(default=None, max_length=2000)


class AppointmentOut(BaseModel):
    id: int
    patient_id: int
    patient_name: str
    doctor_id: int
    doctor_name: str
    specialization: str
    date: str
    time: str
    end_time: str
    status: Literal["Booked", "Completed", "Cancelled", "NoShow"]
    reason: Optional[str] = None
    cancel_reason: Optional[str] = None
    cancelled_by: Optional[str] = None
    notes: Optional[str] = None
    diagnosis: Optional[str] = None
    prescription: Optional[str] = None
    created_at: str
    updated_at: str


class AppointmentPage(BaseModel):
    items: list[AppointmentOut]
    total: int
    limit: int
    offset: int


class SummaryOut(BaseModel):
    role: str
    hospital_name: str
    total_appointments: int
    upcoming: int
    today: int
    completed: int
    cancelled: int
    no_show: int
    needs_update: int
    total_doctors: int
    next_appointment: Optional[AppointmentOut] = None
    upcoming_appointments: list[AppointmentOut]
    todays_appointments: list[AppointmentOut]
    recent_appointments: list[AppointmentOut]
    # doctor only
    patients_seen: Optional[int] = None
    # admin only
    total_patients: Optional[int] = None
    by_status: Optional[dict[str, int]] = None
    by_specialization: Optional[list[dict[str, Any]]] = None
    busiest_doctors: Optional[list[dict[str, Any]]] = None
    last_7_days: Optional[list[dict[str, Any]]] = None
