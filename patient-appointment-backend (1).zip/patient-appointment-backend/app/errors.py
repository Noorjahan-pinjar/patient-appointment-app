class DomainError(Exception):
    """A business-rule problem that should reach the user as a clean HTTP error."""

    def __init__(self, status_code: int, detail: str):
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail
