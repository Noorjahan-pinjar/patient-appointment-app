"""Settings are read from environment variables, so nothing secret lives in the code."""
import os
from dataclasses import dataclass
from datetime import date, datetime

try:  # zoneinfo needs the `tzdata` package on Windows; fall back to the computer's clock.
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None

DEFAULT_SECRET = "dev-only-change-me-please-use-a-long-random-value"


def _int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, str(default)))
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    hospital_name: str
    db_path: str
    secret_key: str
    token_minutes: int
    admin_username: str
    admin_password: str
    cors_origins: list
    timezone: str
    max_advance_days: int
    cancel_hours_before: int
    seed_sample_doctors: bool
    sample_doctor_password: str
    pbkdf2_rounds: int


def load_settings() -> Settings:
    return Settings(
        hospital_name=os.getenv("HOSPITAL_NAME", "Sunrise Care Hospital"),
        db_path=os.getenv("DB_PATH", "appointments.db"),
        secret_key=os.getenv("SECRET_KEY", DEFAULT_SECRET),
        token_minutes=_int("TOKEN_MINUTES", 720),
        admin_username=os.getenv("ADMIN_USERNAME", "admin").strip().lower(),
        admin_password=os.getenv("ADMIN_PASSWORD", "Admin@12345"),
        cors_origins=[o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()],
        timezone=os.getenv("TIMEZONE", "Asia/Kolkata"),
        max_advance_days=_int("MAX_ADVANCE_DAYS", 90),
        cancel_hours_before=_int("CANCEL_HOURS_BEFORE", 2),
        seed_sample_doctors=os.getenv("SEED_SAMPLE_DOCTORS", "true").lower() in ("1", "true", "yes"),
        sample_doctor_password=os.getenv("SAMPLE_DOCTOR_PASSWORD", "Doctor@123"),
        pbkdf2_rounds=_int("PBKDF2_ROUNDS", 200_000),
    )


settings = load_settings()

_tz = None
if ZoneInfo is not None:
    try:
        _tz = ZoneInfo(settings.timezone)
    except Exception:  # unknown zone or tzdata missing
        _tz = None


def now() -> datetime:
    """Current time in the hospital's timezone, without tzinfo (so it compares with stored dates)."""
    if _tz is not None:
        return datetime.now(_tz).replace(tzinfo=None)
    return datetime.now()


def today() -> date:
    return now().date()
