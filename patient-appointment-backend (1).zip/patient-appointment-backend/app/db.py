"""SQLite tables, the connection helper and first-start data."""
import sqlite3

from .config import DEFAULT_SECRET, settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    full_name     TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL CHECK (role IN ('admin', 'doctor', 'patient')),
    email         TEXT,
    phone         TEXT,
    is_active     INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users (lower(email)) WHERE email IS NOT NULL;

CREATE TABLE IF NOT EXISTS patients (
    user_id           INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    dob               TEXT,
    gender            TEXT,
    blood_group       TEXT,
    address           TEXT,
    emergency_contact TEXT
);

CREATE TABLE IF NOT EXISTS doctors (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    specialization   TEXT NOT NULL,
    experience_years INTEGER NOT NULL DEFAULT 0,
    consultation_fee REAL NOT NULL DEFAULT 0,
    bio              TEXT,
    slot_minutes     INTEGER NOT NULL DEFAULT 30,
    is_active        INTEGER NOT NULL DEFAULT 1
);

-- Weekly working hours. weekday: 0 = Monday ... 6 = Sunday. A doctor can have several periods a day.
CREATE TABLE IF NOT EXISTS doctor_schedules (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id  INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
    weekday    INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
    start_time TEXT NOT NULL,
    end_time   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS doctor_leaves (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    doctor_id INTEGER NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
    date      TEXT NOT NULL,
    reason    TEXT,
    UNIQUE (doctor_id, date)
);

CREATE TABLE IF NOT EXISTS appointments (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id    INTEGER NOT NULL REFERENCES users(id),
    doctor_id     INTEGER NOT NULL REFERENCES doctors(id),
    date          TEXT NOT NULL,            -- YYYY-MM-DD
    time          TEXT NOT NULL,            -- HH:MM
    status        TEXT NOT NULL DEFAULT 'Booked'
                  CHECK (status IN ('Booked', 'Completed', 'Cancelled', 'NoShow')),
    reason        TEXT,
    cancel_reason TEXT,
    cancelled_by  TEXT,
    notes         TEXT,
    diagnosis     TEXT,
    prescription  TEXT,
    created_at    TEXT NOT NULL,
    updated_at    TEXT NOT NULL
);
-- The database itself refuses two active bookings for one doctor slot, and two for one patient time.
CREATE UNIQUE INDEX IF NOT EXISTS one_active_booking_per_doctor_slot
    ON appointments (doctor_id, date, time) WHERE status <> 'Cancelled';
CREATE UNIQUE INDEX IF NOT EXISTS one_active_booking_per_patient_time
    ON appointments (patient_id, date, time) WHERE status <> 'Cancelled';
CREATE INDEX IF NOT EXISTS appt_by_date ON appointments (date, time);
CREATE INDEX IF NOT EXISTS appt_by_doctor ON appointments (doctor_id, date);
CREATE INDEX IF NOT EXISTS appt_by_patient ON appointments (patient_id, date);
"""

SAMPLE_DOCTORS = [
    ("dr.meera", "Dr. Meera Nair", "Cardiologist", 14, 800, "Heart care, ECG and blood pressure management."),
    ("dr.rohan", "Dr. Rohan Gupta", "Dermatologist", 9, 600, "Skin, hair and allergy treatment."),
    ("dr.anjali", "Dr. Anjali Rao", "Pediatrician", 11, 500, "Child health, vaccination and growth checks."),
    ("dr.vikram", "Dr. Vikram Shah", "Orthopedic", 16, 900, "Bones, joints and sports injuries."),
    ("dr.farah", "Dr. Farah Khan", "Neurologist", 12, 1000, "Headache, nerve and sleep problems."),
    ("dr.suresh", "Dr. Suresh Pillai", "General Physician", 20, 400, "First consultation for everyday health problems."),
]
# Monday to Saturday, 09:00-13:00 and 14:00-17:00
SAMPLE_HOURS = [(day, s, e) for day in range(6) for s, e in (("09:00", "13:00"), ("14:00", "17:00"))]


def connect(path: str = None) -> sqlite3.Connection:
    conn = sqlite3.connect(path or settings.db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def get_db():
    """FastAPI dependency: one connection per request, always closed."""
    conn = connect()
    try:
        yield conn
    finally:
        conn.close()


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def seed(conn: sqlite3.Connection, sample_doctors: bool = True) -> None:
    """Create the admin account and sample doctors, only when they are missing."""
    from . import services  # imported here to avoid a circular import

    if conn.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'").fetchone()[0] == 0:
        with services.tx(conn):
            services.insert_user(
                conn, username=settings.admin_username, password=settings.admin_password,
                full_name="Hospital Admin", role="admin", email=None, phone=None,
            )

    if sample_doctors and conn.execute("SELECT COUNT(*) FROM doctors").fetchone()[0] == 0:
        for username, name, spec, years, fee, bio in SAMPLE_DOCTORS:
            services.create_doctor(conn, {
                "username": username, "password": settings.sample_doctor_password,
                "full_name": name, "specialization": spec, "experience_years": years,
                "consultation_fee": fee, "bio": bio, "slot_minutes": 30,
                "schedule": [{"weekday": d, "start_time": s, "end_time": e} for d, s, e in SAMPLE_HOURS],
            })


def init_db() -> None:
    if settings.secret_key == DEFAULT_SECRET:
        print("WARNING: SECRET_KEY is not set. Set a long random value before real use.")
    conn = connect()
    try:
        init_schema(conn)
        seed(conn, settings.seed_sample_doctors)
    finally:
        conn.close()
