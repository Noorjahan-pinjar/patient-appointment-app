"""Password hashing, login tokens and a small brute-force guard. No web framework needed here."""
import hashlib
import hmac
import secrets
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt

from .config import settings

ALGORITHM = "HS256"


# ---------------------------------------------------------------- passwords

def hash_password(password: str) -> str:
    salt = secrets.token_hex(16)
    rounds = settings.pbkdf2_rounds
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), rounds)
    return f"{rounds}${salt}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        rounds, salt, expected = stored.split("$")
        digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), int(rounds))
    except ValueError:
        return False
    return hmac.compare_digest(digest.hex(), expected)


# ------------------------------------------------------------------- tokens

def create_token(user_id: int, role: str) -> tuple:
    """Returns (token, seconds_until_expiry)."""
    seconds = settings.token_minutes * 60
    payload = {
        "sub": str(user_id),
        "role": role,
        "exp": datetime.now(timezone.utc) + timedelta(seconds=seconds),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM), seconds


def decode_token(token: str) -> Optional[int]:
    """Returns the user id, or None if the token is missing, expired or tampered with."""
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        return int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        return None


# ------------------------------------------------- login attempt guard (memory)

MAX_FAILURES = 5
LOCK_SECONDS = 15 * 60
_failures: dict = {}  # username -> (failed_count, locked_until_timestamp)


def is_locked(username: str) -> bool:
    _count, locked_until = _failures.get(username, (0, 0))
    return locked_until > time.time()


def record_failure(username: str) -> None:
    count, locked_until = _failures.get(username, (0, 0))
    count += 1
    if count >= MAX_FAILURES:
        count, locked_until = 0, time.time() + LOCK_SECONDS
    _failures[username] = (count, locked_until)


def clear_failures(username: str) -> None:
    _failures.pop(username, None)
