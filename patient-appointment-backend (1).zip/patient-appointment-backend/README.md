# Patient Appointment API (FastAPI + SQLite)

Run (Windows, VS Code terminal, inside this folder):

    python -m venv venv
    venv\Scripts\activate
    pip install -r requirements.txt
    uvicorn app.main:app --reload

Open http://127.0.0.1:8000/docs and use the Authorize button.

First start creates appointments.db, an admin and 6 sample doctors:
  admin     / Admin@12345
  dr.meera  / Doctor@123   (also dr.rohan, dr.anjali, dr.vikram, dr.farah, dr.suresh)
Set SECRET_KEY, ADMIN_PASSWORD and HOSPITAL_NAME as environment variables before real use.

Roles: patient, doctor, admin.
Auth        POST /auth/register, /auth/login, /auth/token, GET/PATCH /auth/me, POST /auth/change-password
Doctors     GET /doctors, /doctors/{id}, /doctors/{id}/slots?date=, /doctors/specializations
            POST /doctors (admin), PATCH/DELETE /doctors/{id}, PUT /doctors/{id}/schedule
            GET/POST /doctors/{id}/leaves, DELETE /doctors/{id}/leaves/{date}
Appointments POST /appointments, GET /appointments, GET /appointments/{id}
            PATCH /appointments/{id}/cancel | reschedule | complete | no-show
Patients    GET/PUT /patients/me, GET /patients, /patients/{id}, /patients/{id}/appointments
Users       GET /users, PATCH /users/{id}/active (admin)
Dashboard   GET /dashboard/summary (patient, doctor or admin numbers)
